/* =========================
   LOCAL STORAGE HELPERS
========================= */

function getUsers(){
  return JSON.parse(localStorage.getItem("users")) || [];
}

function saveUsers(users){
  localStorage.setItem("users", JSON.stringify(users));
}

function getTasks(){
  return JSON.parse(localStorage.getItem("tasks")) || [];
}

function saveTasks(tasks){
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

/* =========================
   SIGNUP SYSTEM
========================= */

const signupForm = document.getElementById("signupForm");

if(signupForm){
  signupForm.addEventListener("submit", function(e){
    e.preventDefault();

    const name = this[0].value.trim();
    const email = this[1].value.trim();
    const password = this[2].value;
    const confirmPassword = this[3].value;

    if(password !== confirmPassword){
      alert("❌ Passwords do not match!");
      return;
    }

    let users = getUsers();

    let exists = users.find(u => u.email === email);

    if(exists){
      alert("❌ User already exists!");
      return;
    }

    users.push({
      name,
      email,
      password
    });

    saveUsers(users);

    alert("✅ Signup Successful!");
    window.location.href = "login.html";
  });
}

/* =========================
   LOGIN SYSTEM
========================= */

const loginForm = document.getElementById("loginForm");

if(loginForm){
  loginForm.addEventListener("submit", function(e){
    e.preventDefault();

    const email = this[0].value.trim();
    const password = this[1].value;

    let users = getUsers();

    let user = users.find(
      u => u.email === email && u.password === password
    );

    if(!user){
      alert("❌ Invalid Email or Password!");
      return;
    }

    localStorage.setItem("currentUser", JSON.stringify(user));

    alert("✅ Login Successful!");
    window.location.href = "dashboard.html";
  });
}

/* =========================
   LOGOUT
========================= */

function logout(){
  localStorage.removeItem("currentUser");
  window.location.href = "login.html";
}

/* =========================
   ADD TASK
========================= */

function addTask(){

  const title = document.getElementById("title").value.trim();
  const desc = document.getElementById("desc").value.trim();
  const date = document.getElementById("date").value;
  const priority = document.getElementById("priority").value;
  const category = document.getElementById("category").value;

  if(title === ""){
    alert("⚠️ Task title required!");
    return;
  }

  let tasks = getTasks();

  const newTask = {
    id: Date.now(),
    title,
    desc,
    date,
    priority,
    category,
    completed:false
  };

  tasks.push(newTask);

  saveTasks(tasks);

  clearInputs();
  renderTasks();
  updateStats();

  alert("✅ Task Added!");
}

/* =========================
   CLEAR INPUTS
========================= */

function clearInputs(){
  document.getElementById("title").value = "";
  document.getElementById("desc").value = "";
  document.getElementById("date").value = "";
}

/* =========================
   RENDER TASKS
========================= */

function renderTasks(){

  const container = document.getElementById("tasks");
  if(!container) return;

  let tasks = getTasks();

  container.innerHTML = "";

  tasks.forEach(task => {

    container.innerHTML += `
      <div class="task glass">

        <h3>${task.title}</h3>
        <p>${task.desc || ""}</p>

        <small>
          📅 ${task.date || "No date"} | 
          ⚡ ${task.priority} | 
          📁 ${task.category}
        </small>

        <div style="margin-top:10px;">

          <button onclick="toggleTask(${task.id})">
            ${task.completed ? "↩ Undo" : "✔ Done"}
          </button>

          <button onclick="deleteTask(${task.id})">
            🗑 Delete
          </button>

        </div>

      </div>
    `;
  });
}

/* =========================
   TOGGLE COMPLETE
========================= */

function toggleTask(id){

  let tasks = getTasks();

  tasks = tasks.map(task => {
    if(task.id === id){
      task.completed = !task.completed;
    }
    return task;
  });

  saveTasks(tasks);

  renderTasks();
  updateStats();
}

/* =========================
   DELETE TASK
========================= */

function deleteTask(id){

  let tasks = getTasks();

  tasks = tasks.filter(task => task.id !== id);

  saveTasks(tasks);

  renderTasks();
  updateStats();

  alert("🗑 Task Deleted!");
}

/* =========================
   STATS UPDATE
========================= */

function updateStats(){

  let tasks = getTasks();

  let total = tasks.length;
  let completed = tasks.filter(t => t.completed).length;
  let pending = total - completed;

  const totalEl = document.getElementById("totalTasks");
  const completedEl = document.getElementById("completedTasks");
  const pendingEl = document.getElementById("pendingTasks");

  if(totalEl){
    totalEl.innerText = total;
    completedEl.innerText = completed;
    pendingEl.innerText = pending;
  }
}

/* =========================
   INIT DASHBOARD
========================= */

document.addEventListener("DOMContentLoaded", () => {

  if(document.getElementById("tasks")){
    renderTasks();
    updateStats();
  }

});
document.addEventListener("DOMContentLoaded", () => {
  document.body.style.opacity = "0";
  document.body.style.transition = "0.6s ease";

  setTimeout(() => {
    document.body.style.opacity = "1";
  }, 100);
});